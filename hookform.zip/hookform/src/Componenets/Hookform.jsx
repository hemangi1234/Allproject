import React, {useEffect, useState} from "react";
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormGroup from '@mui/material/FormGroup';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import Slider from '@mui/material/Slider';
import { Box } from '@mui/system';
import { makeStyles } from '@mui/styles';
import Checkbox from '@mui/material/Checkbox';
import Button from '@mui/material/Button';
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import {useDispatch, useSelector} from "react-redux";
import { useNavigate,useParams } from "react-router-dom";
import {addUser, dataUpdate, getSingleEdit} from "../Redux/Actions/Action";

const useStyles = makeStyles({
    root: {
        textAlign: 'left',
        display: 'inline-block',
        border: '1px solid #000',
        padding: '20px',
        width:'25%'

    },
    box: {
        textAlign: 'center',
    }
});

const schema = yup.object().shape({
    fname: yup.string().required(),
    email: yup.string().email().required(),
    gender: yup.string().required(),
    city: yup.array().min(1),
    age: yup.string().required(),
    slider: yup.number().min(30).max(70).required(),

});

function HookForm(props) {

    const { register, handleSubmit, formState: { errors } } = useForm(
        {resolver: yupResolver(schema),}

        );

    const classes = useStyles(props);

    const[user, setUser] = useState({
        fname:"",
        lname:"",
        email:"",
        gender:"",
        age:"",
        slider:"",
        city:[]
    });
    const {city} =user;
    console.log("user",user)
    const dispatch = useDispatch();
    const navigate = useNavigate();
    let { id } = useParams();
    const users  = useSelector((state) => state.user);

    const onInputChange = e => {
        const {name,value,checked} = e.target;
        if (name === "city"){
            if (checked) {
                user.city.push(value)
                setUser({...user});
            } else {
                let index = user.city.indexOf(value)
                user.city.splice(index,1);
                setUser({...user});
            }
        } else {
            setUser({...user, [e.target.name]: e.target.value})
        }
    };

    const onSubmitHandler = (e) => {
       // e.preventDefault();
        if(id){
            dispatch(dataUpdate(user,id));
        }else {
            dispatch(addUser(user));
        }
        navigate("/HookTable");
    }

    useEffect(() => {
        if(id) {
            dispatch(getSingleEdit(id));
        }
    }, []);

    useEffect(() => {
        if(user.id) {
            setUser(users.user);
        }
    }, [users.user]);

    return(

        <div>
            <Box className={classes.box}>
                <Typography variant="h4" sx={{fontWeight: 'bold', margin: '20px'}}>React Hook Form</Typography>
                <form className={classes.root} onSubmit={handleSubmit(onSubmitHandler)}>
                    <div>
                        <Typography variant="h6" sx={{fontWeight: 'bold'}}>Firstname</Typography>
                        <TextField
                            id="outlined-size-small"
                            size="small"
                            sx={{display: 'grid'}}
                            type="text"
                            value={user?.fname || ''}
                            {...register('fname',{onChange: (e) => onInputChange(e)} )}/>
                        <p style={{ color: 'red' }}>{errors.fname?.message}</p>
                    </div>
                    <br />
                    <div>
                    <Typography variant="h6" sx={{fontWeight: 'bold'}}>Lastname</Typography>
                    <TextField
                        id="outlined-size-small"
                        size="small"
                        sx={{display: 'grid'}}
                        type="text"
                        value={user?.lname || ''}
                        {...register("lname",{onChange: (e) => onInputChange(e)})}
                    />
                    </div>
                    <br />
                    <div>
                        <Typography variant="h6" sx={{fontWeight: 'bold'}}>Email</Typography>
                        <TextField
                            id="outlined-size-small"
                            size="small"
                            sx={{display: 'grid'}}

                            type="email"
                            value={user?.email || ''}
                            {...register("email",{onChange: (e) => onInputChange(e)})}/>
                        <p style={{ color: 'red' }}>{errors.email?.message}</p>
                    </div>
                    <br/>
                    <div>
                        <Typography variant="h6" sx={{fontWeight: 'bold'}}>Gender</Typography>
                    <RadioGroup value={user?.gender || ''}>
                        <FormControlLabel
                            value={"female"}
                            control={<Radio {...register('gender',{onChange: (e) => onInputChange(e)})} />}
                            label="Female"
                            size="small"/>
                        <FormControlLabel
                            value={"male"}
                            control={<Radio {...register('gender',{onChange: (e) => onInputChange(e)})} />}
                            label="Male"
                            size="small"/>
                        <FormControlLabel
                            value={"other"}
                            control={<Radio {...register('gender',{onChange: (e) => onInputChange(e)})} />}
                            label="Other"
                            size="small" />
                    </RadioGroup>
                        <p style={{ color: 'red' }}>{errors.gender && 'gender is required'}</p>
                    </div>
                    <br/>
                    <div>
                    <Typography variant="h6" sx={{fontWeight: 'bold'}}>Age</Typography>
                    <Select
                        size="small"
                        sx={{display: 'grid'}}
                        value={user?.age || ''}
                        {...register('age',{onChange: (e) => onInputChange(e)})}
                    >
                        <MenuItem value="">
                            <em>None</em>
                        </MenuItem>
                        <MenuItem value={10} >10</MenuItem>
                        <MenuItem value={20} >20</MenuItem>
                        <MenuItem value={30} >30</MenuItem>
                    </Select>
                    <p style={{ color: 'red' }}>{errors.age && 'Age is required'}</p>
                    </div>
                    <br/>
                    <div>
                    <Typography variant="h6" sx={{fontWeight: 'bold'}}>select city</Typography>
                    <FormGroup value={city || ''}>
                        <FormControlLabel
                            value="suart"
                            control={<Checkbox color="success" {...register('city',{onChange: (e) => onInputChange(e)})} />}
                            label="suart"
                            checked={city && city.includes("suart")}/>
                        <FormControlLabel
                            value="rajkot"
                            control={<Checkbox color="success" {...register('city',{onChange: (e) => onInputChange(e)})} />}
                            label="rajkot"
                            checked={city && city.includes("rajkot")}/>
                    </FormGroup>
                        <p style={{ color: 'red' }}>{errors.city && 'city is required'}</p>
                    </div>
                    <Slider
                        valueLabelDisplay='auto'
                        color="secondary"
                        {...register('slider',{onChange: (e) => onInputChange(e)})}
                        value={user?.slider || ''}
                    />
                    <p style={{ color: 'red' }}>{errors.slider?.message}</p>
                    <div>
                    <Button variant="contained" color="success" type="submit">SUBMIT</Button>
                    </div>
                </form>
            </Box>
        </div>
    )
}

export default HookForm;
