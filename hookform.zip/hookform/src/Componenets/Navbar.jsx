import React from "react";
import Tabs from '@mui/material/Tabs';
import LinkTab from '@mui/material/Tab';
import {makeStyles} from "@mui/styles";

const useStyles = makeStyles({
    root: {
        color: 'white',
        textAlign: 'center',
    }
});

function Navbar() {
    const classes = useStyles();

    return(
        <div>
            <div style={{textAlign: "center", backgroundColor: "pink",color: "white" }} className="tab">
                <Tabs className={classes.root} aria-label="nav tabs example">
                    <LinkTab label="Form" href="/" />
                    <LinkTab label="Table" href="/Hooktable" />
                </Tabs>
            </div>
        </div>
    )
}
export default Navbar;