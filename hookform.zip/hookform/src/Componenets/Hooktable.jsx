import React, {useEffect} from "react";
import Table from '@mui/material/Table';
import StyledTableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import {useDispatch, useSelector} from "react-redux";
import { deleteUser,loadUsers } from "../Redux/Actions/Action";
import { useNavigate } from "react-router-dom";
import TableBody from "@mui/material/TableBody";
import Typography from "@mui/material/Typography";
import { Box } from '@mui/system';
import {makeStyles} from "@mui/styles";

const useStyles = makeStyles({
    root: {
        border: '1px solid #000',
        padding: '20px',

    },
    box: {
        textAlign: 'center',
        width: '70%',
        margin: '0 auto',
    },
    root1:{
        textAlign: 'center',
        width: '100%',
    }
});

function HookTable(props) {
    const classes = useStyles(props);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const users  = useSelector((state) => state.user);
    useEffect(() => {
        dispatch(loadUsers());
    }, []);

    const onDelete = (id) => {
        dispatch(deleteUser(id));
    };
    return (
        <div className={classes.root1}>
            <Box className={classes.box}>
            <Typography variant="h4" sx={{fontWeight: 'bold', margin: '20px'}}>React Table</Typography>
            <TableContainer component={Paper} className={classes.root}>
                <Table aria-label="customized table">
                    <TableHead>
                        <TableRow>
                            <StyledTableCell align="center">index</StyledTableCell>
                            <StyledTableCell align="center">fname</StyledTableCell>
                            <StyledTableCell align="center">lname</StyledTableCell>
                            <StyledTableCell align="center">email</StyledTableCell>
                            <StyledTableCell align="center">gender</StyledTableCell>
                            <StyledTableCell align="center">age</StyledTableCell>
                            <StyledTableCell align="center">city</StyledTableCell>
                            <StyledTableCell align="center">number</StyledTableCell>
                            <StyledTableCell align="center">actions</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>{users.userData.map((user, index) => {
                        return (
                            <TableRow key={index}>
                                <StyledTableCell align="center">{index + 1}</StyledTableCell>
                                <StyledTableCell align="center">{user.fname}</StyledTableCell>
                                <StyledTableCell align="center">{user.lname}</StyledTableCell>
                                <StyledTableCell align="center">{user.email}</StyledTableCell>
                                <StyledTableCell align="center">{user.gender}</StyledTableCell>
                                <StyledTableCell align="center">{user.age}</StyledTableCell>
                                <StyledTableCell align="center">{user.city}</StyledTableCell>
                                <StyledTableCell align="center">{user.slider}</StyledTableCell>
                                <StyledTableCell align="center">
                                    <Button className="btn"  onClick={() => onDelete(user.id)}>delete</Button>
                                    <Button className="btn"  onClick={() => navigate(`/Hookform/${user.id}`)}>edit</Button>
                                    <Button className="btn"  onClick={() => navigate(`/View/${user.id}`)}>view</Button>
                                </StyledTableCell>
                            </TableRow>)})}
                    </TableBody>
                </Table>
            </TableContainer>
            </Box>
        </div>
    )
}
export default HookTable;