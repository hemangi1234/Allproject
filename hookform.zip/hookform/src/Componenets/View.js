import React, {useEffect} from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import {useDispatch, useSelector} from "react-redux";
import {useParams} from "react-router-dom";
import {useNavigate} from "react-router";
import {userViewed} from "../Redux/Actions/Action";
import {makeStyles} from "@mui/styles";
import {Box} from "@mui/system";

const useStyles = makeStyles({
    root: {
        border: '1px solid #000',
        padding: '20px',

    },
    box: {
        textAlign: 'left',
        width: '20%',
        margin: '0 auto',
    },
});

export default function BasicCard(props) {
    const classes = useStyles(props);
    const users  = useSelector((state) => state.user);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const {user} = users;
    let { id } = useParams();

    useEffect(() => {
        dispatch(userViewed(id));
    }, [id]);
    return (

        <Card sx={{boxShadow:'none', textAlign: 'center',}}>
            <Box className={classes.box}>
            <Typography variant="h4" sx={{fontWeight: 'bold', margin: '20px'}}>View Table</Typography>
            <CardContent className={classes.root}>
                <Typography variant="h6">
                    fname: {user.fname}
                </Typography>
                <Typography variant="h6" >
                    lname: {user.lname}
                </Typography>
                <Typography variant="h6" >
                    email: {user.email}
                </Typography>
                <Typography variant="h6" >
                    gender: {user.gender}
                </Typography>
                <Typography variant="h6" >
                    age: {user.age}
                </Typography>
                <Typography variant="h6" >
                    city: {user.city}
                </Typography>
                <Typography variant="h6" >
                    number: {user.slider}
                </Typography>
            </CardContent>
            </Box>
        </Card>
    );
}
