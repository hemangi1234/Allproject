import React from "react";
import './App.css';
import Hookform from "./Componenets/Hookform";
import Hooktable from "./Componenets/Hooktable";
import {Route, Routes} from 'react-router-dom';
import Navbar from "./Componenets/Navbar";
import View from './Componenets/View';


function App() {
  return (
    <div className="App">
        <Navbar />
        <Routes>
            <Route path="/" element={ <Hookform />} />
            <Route path="/Hookform/:id" element={<Hookform />} />
            <Route path="/Hooktable" element={<Hooktable />} />
            <Route path="/view/:id" element={<View />} />
        </Routes>
    </div>
  );
}

export default App;
