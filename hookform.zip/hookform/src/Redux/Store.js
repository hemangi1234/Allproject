import {createStore, combineReducers, applyMiddleware } from "redux";
import reducer from  "./Reducer/Reducer";
import thunkMiddleware from "redux-thunk";

const combineReducer = combineReducers({
    user: reducer
});

const store = createStore(
    combineReducer,
    {},
    applyMiddleware(thunkMiddleware)
);

export default store;