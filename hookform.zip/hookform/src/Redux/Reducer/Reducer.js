import{ADD_USER,GET_USER, DELETE_USER,EDIT_USER,UPDATE_USER,USER_VIEW} from "../Constants";

const initialstate = {
    userData: [],
    user: {},
    loading: false
}

const userReducers = (state = initialstate,action) =>{
    switch(action.type)
    {
        case GET_USER:
            return{
                ...state,
                userData: action.payload,
                loading: false,
            };
        case ADD_USER:
        case DELETE_USER:
        case EDIT_USER:
            return {
                ...state,
                loading: false,
            };
        case UPDATE_USER:
            return {
                ...state,
                user: action.payload,
                loading: false,
            };
        case USER_VIEW:
            return {
                ...state,
                user: action.payload,
                loading: false,
            };
        default: return initialstate;
    }
};

export default userReducers;