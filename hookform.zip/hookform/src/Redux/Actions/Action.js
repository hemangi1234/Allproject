import {ADD_USER, GET_USER, DELETE_USER, EDIT_USER, UPDATE_USER, USER_VIEW} from "../Constants";
//import {API} from "../Utils/API";
import axios from 'axios';

const getUsers = (users1) => ({
    type: GET_USER,
    payload: users1,
});

const userAdded = () => ({
    type: ADD_USER
});

const userDelete = () => ({
    type: DELETE_USER
});

const dataUpdated = (user) => ({
    type: EDIT_USER,
    payload: user,
});

const getUpdated = () => ({
    type: UPDATE_USER
});

const userView = (user1) => ({
    type: USER_VIEW,
    payload: user1,
});

export const loadUsers = () => {
    // console.log("loadUser")
    return function (dispatch) {
        axios
            .get(`http://localhost:3000/user`)
            .then((resp) => {
                console.log("resp", resp);
                dispatch(getUsers(resp.data))
            })
            .catch((error) => {
                console.log(error);
            });
    };
};

export const addUser = (user) => {
    return function (dispatch) {
        axios
            .post(`http://localhost:3000/user`,user)
            .then((resp) => {
                console.log("resp", resp);
                dispatch(userAdded());
                dispatch(loadUsers());

            })
            .catch((error) => {
                console.log(error);
            });
    };
};

export const deleteUser = (id) => {
    return function (dispatch) {
        axios
            .delete(`http://localhost:3000/user/${id}`)
            .then((resp) => {
                console.log("resp", resp);
                dispatch(userDelete());
                dispatch(loadUsers());

            })
            .catch((error) => {
                console.log(error);
            });
    };
};

/*export const editUser = (user,id) => {
    return function (dispatch) {
        axios
            .put(`http://localhost:3000/user/${id}`,user)
            .then((resp) => {
                console.log("resp", resp);
                dispatch(userEdit());

            })
            .catch((error) => {
                console.log(error);
            });
    };
};

export const updateUser = (id) => {
    return function (dispatch) {
        axios
            .get(`http://localhost:3000/user/${id}`)
            .then((resp) => {
                console.log("resp", resp);
                dispatch(userUpdate(resp.data));

            })
            .catch((error) => {
                console.log(error);
            });
    };
};*/

export const dataUpdate = (user,id) => {
    return function (dispatch) {
        axios
            .put(`http://localhost:3000/user/${id}`,user)
            .then((resp) => {
                console.log("resp", resp);
                dispatch(dataUpdated());
            })
            .catch((error) => {
                console.log(error);
            });
    };
};

export const getSingleEdit = (id) => {
    return function (dispatch) {
        axios
            .get(`http://localhost:3000/user/${id}`)
            .then((resp) => {
                console.log("resp", resp);
                dispatch(getUpdated(resp.data));

            })
            .catch((error) => {
                console.log(error);
            });
    };
};

export const userViewed = (id) => {
    return function (dispatch) {
        axios
            .get(`http://localhost:3000/user/${id}`)
            .then((resp) => {
                console.log("userView", resp);
                dispatch(userView(resp.data));
            })
            .catch((error) => {
                console.log(error);
            });
    };
};